package be.p7n.client.util;

import net.minecraft.client.Minecraft;

public interface Util {
    Minecraft mc = Minecraft.getMinecraft();
}

