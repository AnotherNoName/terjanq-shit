package be.p7n.client;

import club.minnced.discord.rpc.DiscordEventHandlers;
import be.p7n.client.features.modules.client.RPC;
import club.minnced.discord.rpc.DiscordRPC;
import club.minnced.discord.rpc.DiscordRichPresence;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiMainMenu;

public class Discord {
    public static DiscordRichPresence presence;
    private static final DiscordRPC rpc;
    private static RPC discordrpc;
    private static Thread thread;

    public static void start() {
        final DiscordEventHandlers handlers = new DiscordEventHandlers();
        Discord.rpc.Discord_Initialize("897131142153637908", handlers, true, "");
        Discord.presence.details = Minecraft.getMinecraft().currentScreen instanceof GuiMainMenu ? "in the main menu" : "Heiling Hitler on " + (Minecraft.getMinecraft().currentServerData != null ? (RPC.INSTANCE.showip.getValue().booleanValue() ?  Minecraft.getMinecraft().currentServerData.serverIP + "." : " multiplayer") : " singleplayer");
        Discord.presence.state = RPC.INSTANCE.rpcstate.getValue();
        Discord.presence.largeImageKey = "logo";
        Discord.presence.largeImageText = Reich.MODNAME + " " + Reich.MODVER;
        Discord.rpc.Discord_UpdatePresence(Discord.presence);
        (Discord.thread = new Thread(() -> {
            while (!Thread.currentThread().isInterrupted()) {
                Discord.rpc.Discord_RunCallbacks();
                Discord.presence.details = Minecraft.getMinecraft().currentScreen instanceof GuiMainMenu ? "in the main menu" : "Heiling Hitler on " + (Minecraft.getMinecraft().currentServerData != null ? (RPC.INSTANCE.showip.getValue().booleanValue() ?  Minecraft.getMinecraft().currentServerData.serverIP + "." : " multiplayer") : " singleplayer");
                Discord.presence.state = RPC.INSTANCE.rpcstate.getValue();
                Discord.rpc.Discord_UpdatePresence(Discord.presence);
                try {
                    Thread.sleep(2000L);
                }
                catch (InterruptedException ex) {}
            }
        }, "RPC-Callback-Handler")).start();
    }

    public static void stop() {
        if (Discord.thread != null && !Discord.thread.isInterrupted()) {
            Discord.thread.interrupt();
        }
        Discord.rpc.Discord_Shutdown();
    }

    static {
        rpc = DiscordRPC.INSTANCE;
        Discord.presence = new DiscordRichPresence();
    }
}