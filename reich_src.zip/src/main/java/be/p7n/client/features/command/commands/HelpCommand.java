package be.p7n.client.features.command.commands;

import be.p7n.client.Reich;
import com.mojang.realmsclient.gui.ChatFormatting;
import be.p7n.client.features.command.Command;

public class HelpCommand
        extends Command {
    public HelpCommand() {
        super("help");
    }

    @Override
    public void execute(String[] commands) {
        HelpCommand.sendMessage("Commands: ");
        for (Command command : Reich.commandManager.getCommands()) {
            HelpCommand.sendMessage(ChatFormatting.GRAY + Reich.commandManager.getPrefix() + command.getName());
        }
    }
}

