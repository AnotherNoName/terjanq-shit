package be.p7n.client.features.command.commands;

import be.p7n.client.Reich;
import be.p7n.client.features.command.Command;

public class ReloadCommand
        extends Command {
    public ReloadCommand() {
        super("reload", new String[0]);
    }

    @Override
    public void execute(String[] commands) {
        Reich.reload();
    }
}

