package be.p7n.client.features.modules.client;

import be.p7n.client.Reich;
import be.p7n.client.features.modules.client.HUD;
import be.p7n.client.event.events.Render2DEvent;
import be.p7n.client.features.modules.Module;
import be.p7n.client.features.setting.Setting;
import be.p7n.client.util.ColorUtil;
import be.p7n.client.util.RenderUtil;
import be.p7n.client.util.Timer;

public class Watermark extends Module {

    Timer delayTimer = new Timer();
    public Setting<Boolean> account = this.register(new Setting("Account", true));
    public Setting<Boolean> ping = this.register(new Setting("Ping", true));
    public Setting<Integer> X = this.register(new Setting("WatermarkX", 0, 0, 300));
    public Setting<Integer> Y = this.register(new Setting("WatermarkY", 0, 0, 300));
    public Setting<Integer> delay = this.register(new Setting<Object>("Delay", 240, 0, 600));
    public int red = 1;
    public int green = 1;
    public int blue = 1;

    private String message = "";

    public Watermark() {
        super("Watermark", "noat em cee actually makes something", Module.Category.CLIENT, true, false, false);
    }

    @Override
    public void onRender2D(Render2DEvent event) {
        drawCsgoWatermark();
    }

    public void drawCsgoWatermark() {
        int padding = 5;
        message = HUD.getInstance().command.getValue() + " " + Reich.MODVER + (account.getValue() ? " / " + mc.player.getName() : "") + (ping.getValue() ? " / " + Reich.serverManager.getPing() + "ms" : "");
        Integer textWidth = mc.fontRenderer.getStringWidth(message); // taken from wurst+ 3
        Integer textHeight = mc.fontRenderer.FONT_HEIGHT; // taken from wurst+ 3
        RenderUtil.drawRectangleCorrectly(X.getValue() - 4, Y.getValue() - 4, textWidth + 16, textHeight + 12, ColorUtil.toRGBA(22, 22, 22, 255));
        RenderUtil.drawRectangleCorrectly(X.getValue(), Y.getValue(), textWidth + 4, textHeight + 4, ColorUtil.toRGBA(0, 0, 0, 255));
        RenderUtil.drawRectangleCorrectly(X.getValue(), Y.getValue(), textWidth + 8, textHeight + 4, ColorUtil.toRGBA(0, 0, 0, 255));
        RenderUtil.drawRectangleCorrectly(X.getValue(), Y.getValue(), textWidth + 8, 1, ColorUtil.rainbow(this.delay.getValue()).hashCode());
        mc.fontRenderer.drawString(message, X.getValue() + 3, Y.getValue() + 3, ColorUtil.toRGBA(255, 255, 255, 255), false);
    }
}
