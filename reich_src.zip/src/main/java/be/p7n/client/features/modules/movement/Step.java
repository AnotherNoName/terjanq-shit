package be.p7n.client.features.modules.movement;

import be.p7n.client.features.modules.Module;

public class Step
        extends Module {
    public Step() {
        super("Step", "Speed.", Category.MOVEMENT, true, false, false);
    }
}