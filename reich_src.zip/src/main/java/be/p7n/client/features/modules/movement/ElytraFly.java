package be.p7n.client.features.modules.movement;

import be.p7n.client.event.events.PacketEvent;
import be.p7n.client.event.events.PlayerTravelEvent;
import be.p7n.client.features.modules.Module;
import be.p7n.client.features.setting.Setting;
import be.p7n.client.util.MathUtil;
import be.p7n.client.util.Timer;
import net.minecraft.init.Items;
import net.minecraft.inventory.ClickType;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemElytra;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class ElytraFly extends Module {

    public ElytraFly(){
        super("ElytraFly", "Modifys the flight of elytras", Category.MOVEMENT, true, false, false);
    }

    private Setting<Float> speed = register(new Setting<Float>("Speed", 1.82f, 0.0f, 10.0f));
    private Setting<Float> UpSpeed = register(new Setting<Float>("UpSpeed", 2.0f, 2.0f, 10.0f));
    private Setting<Float> DownSpeed = register(new Setting<Float>("DownSpeed", 1.82f, 0.0f, 10.0f));
    private Setting<Float> GlideSpeed = register(new Setting<Float>("GlideSpeed", 0.0f, 1.0f, 10.0f));
    private Setting<Boolean> Accelerate = register(new Setting<Boolean>("Accelerate", true));
    private Setting<Integer> vAccelerationTimer = register(new Setting<Integer>("Timer", 1000, 0, 10000));
    private Setting<Float> RotationPitch = register(new Setting<Float>("RotationPitch", 0.0f, -90.0f, 90.0f));
    private Setting<Boolean> CancelInWater = register(new Setting<Boolean>("CancelInWater", true));
    private Setting<Boolean> InstantFly = register(new Setting<Boolean>("InstantFly", true));
    private Setting<Boolean> EquipElytra = register(new Setting<Boolean>("EquipElytra", false));
    private Setting<Boolean> PitchSpoof = register(new Setting<Boolean>("PitchSpoof", true));
    private Setting<Boolean> infDura = register(new Setting<Boolean>("InfiniteDurability", true));

    private Timer PacketTimer = new Timer();
    private Timer AccelerationTimer = new Timer();
    private Timer AccelerationResetTimer = new Timer();
    private Timer InstantFlyTimer = new Timer();

    private int ElytraSlot = -1;

    @Override
    public void onEnable() {
        super.onEnable();

        ElytraSlot = -1;

        if (EquipElytra.getValue()) {
            if (mc.player != null
                    && mc.player.getItemStackFromSlot(EntityEquipmentSlot.CHEST).getItem() != Items.ELYTRA) {
                for (int l_I = 0; l_I < 44; ++l_I) {
                    ItemStack l_Stack = mc.player.inventory.getStackInSlot(l_I);

                    if (l_Stack.isEmpty() || l_Stack.getItem() != Items.ELYTRA)
                        continue;

                    ItemElytra l_Elytra = (ItemElytra) l_Stack.getItem();

                    ElytraSlot = l_I;
                    break;
                }

                if (ElytraSlot != -1) {
                    boolean l_HasArmorAtChest = mc.player.getItemStackFromSlot(EntityEquipmentSlot.CHEST)
                            .getItem() != Items.AIR;

                    mc.playerController.windowClick(mc.player.inventoryContainer.windowId, ElytraSlot, 0,
                            ClickType.PICKUP, mc.player);
                    mc.playerController.windowClick(mc.player.inventoryContainer.windowId, 6, 0, ClickType.PICKUP,
                            mc.player);

                    if (l_HasArmorAtChest)
                        mc.playerController.windowClick(mc.player.inventoryContainer.windowId, ElytraSlot, 0,
                                ClickType.PICKUP, mc.player);
                }
            }
        }
    }

    @Override
    public void onDisable() {
        super.onDisable();

        if (mc.player == null)
            return;

        if (ElytraSlot != -1) {
            boolean l_HasItem = !mc.player.inventory.getStackInSlot(ElytraSlot).isEmpty()
                    || mc.player.inventory.getStackInSlot(ElytraSlot).getItem() != Items.AIR;

            mc.playerController.windowClick(mc.player.inventoryContainer.windowId, 6, 0, ClickType.PICKUP, mc.player);
            mc.playerController.windowClick(mc.player.inventoryContainer.windowId, ElytraSlot, 0, ClickType.PICKUP,
                    mc.player);

            if (l_HasItem)
                mc.playerController.windowClick(mc.player.inventoryContainer.windowId, 6, 0, ClickType.PICKUP,
                        mc.player);
        }
    }

    @SubscribeEvent
    public void onPacketSend(PlayerTravelEvent event) {
        if (mc.player == null) /// < Ignore if Flight is on: ex flat flying
            return;

        /// Player must be wearing an elytra.
        if (mc.player.getItemStackFromSlot(EntityEquipmentSlot.CHEST).getItem() != Items.ELYTRA)
            return;

        if (!mc.player.isElytraFlying()) {
            if ((!mc.player.onGround && InstantFly.getValue()) && !infDura.getValue()) {
                if (!InstantFlyTimer.passedMs(1000))
                    return;

                InstantFlyTimer.reset();

                mc.player.connection.sendPacket(new CPacketEntityAction(mc.player, CPacketEntityAction.Action.START_FALL_FLYING));
            }

            return;
        }

        HandleNormalModeElytra(event);

    }

    public void HandleNormalModeElytra(PlayerTravelEvent p_Travel) {
        double l_YHeight = mc.player.posY;

        boolean l_IsMoveKeyDown = mc.player.movementInput.moveForward > 0 || mc.player.movementInput.moveStrafe > 0;

        boolean l_CancelInWater = !mc.player.isInWater() && !mc.player.isInLava() && CancelInWater.getValue();

        if (mc.player.movementInput.jump) {
            p_Travel.setCanceled(true);
            Accelerate();
            return;
        }

        if (!l_IsMoveKeyDown) {
            AccelerationTimer.resetTimeSkipTo(-vAccelerationTimer.getValue());
        } else if ((mc.player.rotationPitch <= RotationPitch.getValue())
                && l_CancelInWater) {
            if (Accelerate.getValue()) {
                if (AccelerationTimer.passedMs(vAccelerationTimer.getValue())) {
                    Accelerate();
                    return;
                }
            }
            return;
        }

        p_Travel.setCanceled(true);
        Accelerate();
    }

    public void Accelerate() {
        if (AccelerationResetTimer.passedMs(vAccelerationTimer.getValue())) {
            AccelerationResetTimer.reset();
            AccelerationTimer.reset();
        }

        float l_Speed = this.speed.getValue();

        final double[] dir = MathUtil.directionSpeed(l_Speed);

        mc.player.motionY = -(GlideSpeed.getValue() / 10000f);

        if (mc.player.movementInput.moveStrafe != 0 || mc.player.movementInput.moveForward != 0) {
            mc.player.motionX = dir[0];
            mc.player.motionZ = dir[1];
        } else {
            mc.player.motionX = 0;
            mc.player.motionZ = 0;
        }

//        if (mc.player.movementInput.jump) {
//            mc.player.rotationPitch = -45;
//        }

        if (mc.player.movementInput.sneak)
            mc.player.motionY = -DownSpeed.getValue();

        mc.player.prevLimbSwingAmount = 0;
        mc.player.limbSwingAmount = 0;
        mc.player.limbSwing = 0;
    }

    private void HandleControlMode(PlayerTravelEvent p_Event) {
        final double[] dir = MathUtil.directionSpeed(speed.getValue());

        if (mc.player.movementInput.moveStrafe != 0 || mc.player.movementInput.moveForward != 0) {
            mc.player.motionX = dir[0];
            mc.player.motionZ = dir[1];

            mc.player.motionX -= (mc.player.motionX * (Math.abs(mc.player.rotationPitch) + 90) / 90)
                    - mc.player.motionX;
            mc.player.motionZ -= (mc.player.motionZ * (Math.abs(mc.player.rotationPitch) + 90) / 90)
                    - mc.player.motionZ;
        } else {
            mc.player.motionX = 0;
            mc.player.motionZ = 0;
        }

        mc.player.motionY = (-MathUtil.degToRad(mc.player.rotationPitch)) * mc.player.movementInput.moveForward;

        mc.player.prevLimbSwingAmount = 0;
        mc.player.limbSwingAmount = 0;
        mc.player.limbSwing = 0;
        p_Event.setCanceled(true);
    }

    @SubscribeEvent
    public void onPacketSend(PacketEvent.Send event) {
        if (event.getPacket() instanceof CPacketPlayer && PitchSpoof.getValue()) {
            if (!mc.player.isElytraFlying())
                return;

            if (event.getPacket() instanceof CPacketPlayer.PositionRotation && PitchSpoof.getValue()) {
                CPacketPlayer.PositionRotation rotation = event.getPacket();

                mc.getConnection()
                        .sendPacket(new CPacketPlayer.Position(rotation.x, rotation.y, rotation.z, rotation.onGround));
                event.setCanceled(true);
            } else if (event.getPacket() instanceof CPacketPlayer.Rotation && PitchSpoof.getValue()) {
                event.setCanceled(true);
            }
        }
    }

}
