package be.p7n.client.features.modules.render;

import be.p7n.client.features.modules.Module;
import be.p7n.client.features.setting.Setting;

public class ViewmodelChanger extends Module {

    public static ViewmodelChanger INSTANCE;

    public Setting<Float> translateX = this.register(new Setting<Float>("TranslateX", 0f, -100f, 100f));
    public Setting<Float> translateY = this.register(new Setting<Float>("TranslateY", 0f, -100f, 100f));
    public Setting<Float> translateZ = this.register(new Setting<Float>("TranslateZ", 0f, -100f, 100f));
    public Setting<Float> scaleX = this.register(new Setting<Float>("ScaleX", 100f, 0f, 100f));
    public Setting<Float> scaleY = this.register(new Setting<Float>("ScaleY", 100f, 0f, 100f));
    public Setting<Float> scaleZ = this.register(new Setting<Float>("ScaleZ", 100f, 0f, 100f));
    public Setting<Float> rotateX = this.register(new Setting<Float>("RotationX", 0f, 0f, 100f));
    public Setting<Float> rotateY = this.register(new Setting<Float>("RotationY", 0f, 0f, 100f));
    public Setting<Float> rotateZ = this.register(new Setting<Float>("RotationZ", 0f, 0f, 100f));

    public static ViewmodelChanger getInstance() {
        if(INSTANCE == null) INSTANCE = new ViewmodelChanger();
        return INSTANCE;
    }

    public ViewmodelChanger(){
        super("ViewModel", "Changes your ViewModel", Category.RENDER, true, false, false);
        INSTANCE = this;
    }
}
