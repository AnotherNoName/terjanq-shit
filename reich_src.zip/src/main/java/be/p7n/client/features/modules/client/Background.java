package be.p7n.client.features.modules.client;

import be.p7n.client.features.modules.Module;
import be.p7n.client.features.setting.Setting;
import be.p7n.client.util.Util;
import net.minecraft.client.*;
import net.minecraft.client.gui.inventory.*;
import net.minecraft.client.gui.*;
import net.minecraftforge.fml.client.*;
import net.minecraft.client.renderer.*;
import net.minecraft.entity.player.*;
import net.minecraft.util.*;

public class Background extends Module
{
    final Minecraft mc;

    public Setting<Mode> shader = register(new Setting<Mode>("Mode", Mode.deconverge));

    public Background() {
        super("Background", "nigga", Category.CLIENT, true, false, false);
        this.mc = Minecraft.getMinecraft();
    }

    public void onDisable() {
        if (this.mc.world != null) {
            be.p7n.client.util.Util.mc.entityRenderer.getShaderGroup().deleteShaderGroup();
        }
    }

    public void onUpdate() {
        if (this.mc.world != null) {
            if (ClickGui.getInstance().isEnabled() || this.mc.currentScreen instanceof GuiContainer || this.mc.currentScreen instanceof GuiChat || this.mc.currentScreen instanceof GuiConfirmOpenLink || this.mc.currentScreen instanceof GuiEditSign || this.mc.currentScreen instanceof GuiGameOver || this.mc.currentScreen instanceof GuiOptions || this.mc.currentScreen instanceof GuiIngameMenu || this.mc.currentScreen instanceof GuiVideoSettings || this.mc.currentScreen instanceof GuiScreenOptionsSounds || this.mc.currentScreen instanceof GuiControls || this.mc.currentScreen instanceof GuiCustomizeSkin || this.mc.currentScreen instanceof GuiModList) {
                if (OpenGlHelper.shadersSupported && be.p7n.client.util.Util.mc.getRenderViewEntity() instanceof EntityPlayer) {
                    if (be.p7n.client.util.Util.mc.entityRenderer.getShaderGroup() != null) {
                        be.p7n.client.util.Util.mc.entityRenderer.getShaderGroup().deleteShaderGroup();
                    }
                    try {
                        be.p7n.client.util.Util.mc.entityRenderer.loadShader(new ResourceLocation("shaders/post/" + shader.getValue() + ".json"));
                    }
                    catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                else if (be.p7n.client.util.Util.mc.entityRenderer.getShaderGroup() != null && be.p7n.client.util.Util.mc.currentScreen == null) {
                    be.p7n.client.util.Util.mc.entityRenderer.getShaderGroup().deleteShaderGroup();
                }
            }
            else if (be.p7n.client.util.Util.mc.entityRenderer.getShaderGroup() != null) {
                Util.mc.entityRenderer.getShaderGroup().deleteShaderGroup();
            }
        }
    }
    public enum Mode {
        blur, deconverge
    }
}