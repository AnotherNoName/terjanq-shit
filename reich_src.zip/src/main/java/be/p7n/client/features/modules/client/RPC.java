package be.p7n.client.features.modules.client;

import be.p7n.client.Discord;
import be.p7n.client.features.modules.Module;
import be.p7n.client.features.setting.Setting;

public class RPC extends Module
{
    public static RPC INSTANCE;
    public Setting<String> rpcstate = register(new Setting("State", "winning"));
    public Setting<Boolean> showip = register(new Setting("ShowIP", Boolean.valueOf(false), "Show the ip of the current server"));
    public RPC() {
        super("RPC", "Discord rich presence", Category.CLIENT, false, false, false);
        RPC.INSTANCE = this;
    }

    @Override
    public void onEnable() {
        super.onEnable();
        Discord.start();
    }

    @Override
    public void onDisable() {
        super.onDisable();
        Discord.stop();
    }

    @Override
    public void onLoad() {
        super.onLoad();
        Discord.start();
    }
}