package be.p7n.client.features.modules.misc;

import be.p7n.client.Reich;
import com.mojang.realmsclient.gui.ChatFormatting;
import be.p7n.client.features.command.Command;
import be.p7n.client.features.modules.Module;
import be.p7n.client.features.setting.Setting;
import net.minecraft.entity.player.EntityPlayer;

import java.util.HashMap;

public class PopCounter
        extends Module {

    public static HashMap<String, Integer> TotemPopContainer = new HashMap();
    private static PopCounter INSTANCE = new PopCounter();

    private Setting<Boolean> showOwn = this.register(new Setting<Boolean>("Show Own", true));
    private Setting<Boolean> rainbow = this.register(new Setting<Boolean>("Rainbow Pops", true));

    public PopCounter() {
        super("PopCounter", "Counts other players totem pops.", Module.Category.MISC, true, false, true);
        this.setInstance();
    }

    public static PopCounter getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new PopCounter();
        }
        return INSTANCE;
    }

    private void setInstance() {
        INSTANCE = this;
    }

    @Override
    public void onEnable() {
        TotemPopContainer.clear();
    }

    public void onDeath(EntityPlayer player) {
        if (TotemPopContainer.containsKey(player.getName())) {
            int l_Count = TotemPopContainer.get(player.getName());
            TotemPopContainer.remove(player.getName());
            if(this.isOn()) {
                if (Reich.friendManager.isFriend(player.getName())) {
                    Command.sendTempMessageID(ChatFormatting.AQUA + player.getName() + ChatFormatting.GRAY + " died after popping their " + (rainbow.getValue() ? "\u00a7+" : ChatFormatting.GREEN) + l_Count + getPopString(l_Count) + ChatFormatting.GRAY + " totem!", -42069);
                } else {
                    Command.sendTempMessageID(ChatFormatting.RED + player.getName() + ChatFormatting.GRAY + " died after popping their " + (rainbow.getValue() ? "\u00a7+" : ChatFormatting.GREEN) + l_Count + getPopString(l_Count) + ChatFormatting.GRAY + " totem!", -42069);
                }
            }
        }
    }

    public void onTotemPop(EntityPlayer player) {
        if (PopCounter.fullNullCheck()) {
            return;
        }
        if (PopCounter.mc.player.equals(player) && !showOwn.getValue()) {
            return;
        }
        int l_Count = 1;
        if (TotemPopContainer.containsKey(player.getName())) {
            l_Count = TotemPopContainer.get(player.getName());
            TotemPopContainer.put(player.getName(), ++l_Count);
        } else {
            TotemPopContainer.put(player.getName(), l_Count);
        }
        if(this.isOn()) {
            if (Reich.friendManager.isFriend(player.getName())) {
                Command.sendTempMessageID(ChatFormatting.AQUA + player.getName() + ChatFormatting.GRAY + " popped their " + (rainbow.getValue() ? "\u00a7+" : ChatFormatting.GREEN) + l_Count + getPopString(l_Count) + ChatFormatting.GRAY + " totem.", -1337);
            } else {
                Command.sendTempMessageID(ChatFormatting.RED + player.getName() + ChatFormatting.GRAY + " popped their " + (rainbow.getValue() ? "\u00a7+" : ChatFormatting.GREEN) + l_Count + getPopString(l_Count) + ChatFormatting.GRAY + " totem.", -1337);
            }
        }
    }

    public String getPopString(int pops){
        if(pops == 1){
            return "st";
        }
        else if(pops == 2){
            return "nd";
        }
        else if(pops == 3){
            return "rd";
        }
        else if(pops >= 4 && pops < 21){
            return "th";
        } else {
            int lastDigit = pops % 10;
            if(lastDigit == 1){
                return "st";
            }
            else if(lastDigit == 2){
                return "nd";
            }
            else if(lastDigit == 3){
                return "rd";
            }else{
                return "th";
            }
        }
    }

}

