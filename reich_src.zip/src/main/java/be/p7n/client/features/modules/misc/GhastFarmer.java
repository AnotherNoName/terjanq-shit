package be.p7n.client.features.modules.misc;

import be.p7n.client.features.command.Command;
import be.p7n.client.features.modules.Module;
import be.p7n.client.features.setting.Setting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.monster.EntityGhast;
import net.minecraft.init.SoundEvents;

import java.util.HashSet;
import java.util.Set;

public class GhastFarmer extends Module {

    private Set<Entity> entities = new HashSet<Entity>();

    private Setting<Boolean> notifications = this.register(new Setting<Boolean>("Notifications", true));
    private Setting<Boolean> packetFly = this.register(new Setting<Boolean>("PacketFly", false));
    private Setting<Boolean> publicChat = this.register(new Setting<Boolean>("PublicChat", false));
    public Setting<String> prefix = register(new Setting("FuturePrefix", "@", v -> packetFly.getValue()));

    public GhastFarmer(){
            super("GhastFarmer", "Modifies behaviour in presence of a Ghast", Category.MISC, true, false, false);
    }

    @Override
    public void onUpdate() {
        for (Entity entity : mc.world.loadedEntityList) {
            if (!(entity instanceof EntityGhast) || this.entities.contains(entity)) continue;
            if (packetFly.getValue()) {
                mc.player.sendChatMessage(prefix.getValue() + "toggle packetfly off");
            }
            if (notifications.getValue()) {
                Command.sendMessage("Ghast detected at " + entity.getPosition().getX() + " " + entity.getPosition().getY() + " " + entity.getPosition().getZ());
                GhastFarmer.mc.player.playSound(SoundEvents.ENTITY_PLAYER_LEVELUP, 1.0f, 1.0f);
            }
            if (publicChat.getValue()) {
                mc.player.sendChatMessage("A ghast has spawned thanks to Reich Client!");
            }
            this.entities.add(entity);
            }
        }

}
