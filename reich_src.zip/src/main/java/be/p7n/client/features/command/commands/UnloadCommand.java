package be.p7n.client.features.command.commands;

import be.p7n.client.Reich;
import be.p7n.client.features.command.Command;

public class UnloadCommand
        extends Command {
    public UnloadCommand() {
        super("unload", new String[0]);
    }

    @Override
    public void execute(String[] commands) {
        Reich.unload(true);
    }
}

