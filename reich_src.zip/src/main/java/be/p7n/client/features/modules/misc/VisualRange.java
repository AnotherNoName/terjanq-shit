package be.p7n.client.features.modules.misc;

import be.p7n.client.Reich;
import be.p7n.client.features.command.Command;
import be.p7n.client.features.modules.Module;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import com.mojang.realmsclient.gui.ChatFormatting;

import java.util.*;

public class VisualRange extends Module {

    public VisualRange() {
        super("VisualRange", "Tells you when a player enters your render distance", Category.MISC, false, false, false);
    }


    private List<String> knownPlayers = new ArrayList<>();;
    private Set<EntityPlayer> str = Collections.newSetFromMap(new WeakHashMap<>());

    @Override
    public void onToggle() {
        this.knownPlayers = new ArrayList<>();
    }

    @Override
    public void onTick() {

        List<String> tickPlayerList = new ArrayList<>();

        try {
            for (Entity entity : mc.world.getLoadedEntityList()) {
                if (entity instanceof EntityPlayer) {
                    tickPlayerList.add(entity.getName());
                }
            }
        }catch (Exception e){

        }

        if (tickPlayerList.size() > 0) {
            for (String playerName : tickPlayerList) {
                if (playerName.equals(mc.player.getName())) {
                    continue;
                }
                if (!knownPlayers.contains(playerName)) {
                    knownPlayers.add(playerName);
                    if (Reich.friendManager.isFriend(playerName)) {
                        Command.sendTempMessageID(ChatFormatting.AQUA + playerName + ChatFormatting.GRAY + " has entered your visual range", -8043809);
                    } else {
                        Command.sendTempMessageID(ChatFormatting.RED + playerName + ChatFormatting.GRAY + " has entered your visual range", -8043809);
                    }
                    mc.player.playSound(SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, 0.5f, 1.0f);
                    return;
                }
            }
        }

        if (knownPlayers.size() > 0) {
            for (String playerName : knownPlayers) {
                if (!tickPlayerList.contains(playerName)) {
                    knownPlayers.remove(playerName);
                    return;
                }
            }
        }
    }

}
