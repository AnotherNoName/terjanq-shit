package be.p7n.client.features.modules.combat;

import be.p7n.client.features.command.Command;
import be.p7n.client.features.modules.Module;
import be.p7n.client.features.setting.Setting;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

public class OldfagBurrow
        extends Module {

    private BlockPos playerPos;

    public Setting<Boolean> Echest = register(new Setting("PreferEchest",false));
    private final Setting<Boolean> rotate = this.register(new Setting<Boolean>("Rotate", true));

    public OldfagBurrow() {
        super("OldfagBurrow", "Sets you into a block", Module.Category.COMBAT, true, false, true);
        INSTANCE = this;
    }

    private final double[] firstPositions = new double[]{0.42, 0.75, 1.0, 1.16};

    public static OldfagBurrow INSTANCE;

    public static OldfagBurrow getInstance() {
        if (OldfagBurrow.INSTANCE == null) {
            OldfagBurrow.INSTANCE = new OldfagBurrow();
        }
        return OldfagBurrow.INSTANCE;
    }

    public static boolean isInterceptedByOther(final BlockPos pos) {
        for (final Entity entity : mc.world.loadedEntityList) {
            if (entity.equals(mc.player)) continue;
            if (entity instanceof EntityItem) continue;
            if (new AxisAlignedBB(pos).intersects(entity.getEntityBoundingBox())) return true;
        }

        return false;
    }


    @Override
    public void onEnable() {
        if (mc.player == null || mc.world == null) {
            this.disable();
            return;
        }

        if(getBlock() == null){
            Command.sendMessage("No Blocks In Hotbar");
            this.disable();
            return;
        }

        this.playerPos = new BlockPos(mc.player.posX, mc.player.posY, mc.player.posZ);
        if (mc.world.getBlockState(this.playerPos).getBlock().equals(getBlock())) {
            this.disable();
            return;
        }

        if (isInterceptedByOther(this.playerPos)) {
            this.disable();
            return;
        }

        mc.player.connection.sendPacket(new CPacketEntityAction(mc.player, CPacketEntityAction.Action.START_SNEAKING));

            for (final double position : this.firstPositions) {
                mc.player.connection.sendPacket(new CPacketPlayer.Position(mc.player.posX + position,
                        mc.player.posY + position, mc.player.posZ + position, mc.player.onGround));
        }

        placeBlock(this.playerPos, getHotbarSlot(getBlock()));

        doBurrow();
    }

    @Override
    public void onUpdate() {
        //doBurrow();
    }

    public void doBurrow() {

        //Scan for blank space to tp to
        int offset = 2;
        for(int y = offset; y<mc.world.getHeight()-mc.player.posY; y++){
            IBlockState scanState1 = mc.world.getBlockState(new BlockPos(mc.player.posX, mc.player.posY, mc.player.posZ).up(y));
            if(scanState1.getBlock() == Blocks.AIR){
                IBlockState scanState2 = mc.world.getBlockState(new BlockPos(mc.player.posX, mc.player.posY, mc.player.posZ).up(y+1));
                if(scanState2.getBlock() == Blocks.AIR){
                    offset = y;
                    break;
                }
            }
        }

            mc.player.connection.sendPacket(new CPacketPlayer.Position(mc.player.posX + 1.16,
                    mc.player.posY + 1.16, mc.player.posZ, false));

        this.disable();
    }

    @Override
    public void onDisable() {
        mc.player.connection
                .sendPacket(new CPacketEntityAction(mc.player, CPacketEntityAction.Action.STOP_SNEAKING));
    }

    public void placeBlock(final BlockPos pos) {
        for (final EnumFacing enumFacing : EnumFacing.values()) {
            if (!mc.world.getBlockState(pos.offset(enumFacing)).getBlock().equals(Blocks.AIR)) {
                final Vec3d vec = new Vec3d(pos.getX() + 0.5D + (double) enumFacing.getXOffset() * 0.5D,
                        pos.getY() + 0.5D + (double) enumFacing.getYOffset() * 0.5D,
                        pos.getZ() + 0.5D + (double) enumFacing.getZOffset() * 0.5D);

                final float[] old = new float[]{mc.player.rotationYaw, mc.player.rotationPitch};

                if (rotate.getValue()) {
                    mc.player.connection.sendPacket(new CPacketPlayer.Rotation(
                            (float) Math.toDegrees(Math.atan2((vec.z - mc.player.posZ), (vec.x - mc.player.posX))) - 90.0F,
                            (float) (-Math
                                    .toDegrees(Math.atan2((vec.y - (mc.player.posY + (double) mc.player.getEyeHeight())),
                                            (Math.sqrt((vec.x - mc.player.posX) * (vec.x - mc.player.posX)
                                                    + (vec.z - mc.player.posZ) * (vec.z - mc.player.posZ)))))),
                            false));
                }

                Vec3d vector = new Vec3d(pos);
                float f = (float) (vector.x - (double) pos.getX());
                float f1 = (float) (vector.y - (double) pos.getY());
                float f2 = (float) (vector.z - (double) pos.getZ());
                mc.player.connection.sendPacket(new CPacketPlayerTryUseItemOnBlock(pos.offset(enumFacing), enumFacing.getOpposite(), EnumHand.MAIN_HAND, f, f1, f2));
                mc.player.swingArm(EnumHand.MAIN_HAND);

                if (rotate.getValue()) {
                    mc.player.connection.sendPacket(new CPacketPlayer.Rotation(old[0], old[1], false));
                }

                return;
            }
        }
    }

    public void placeBlock(final BlockPos pos, final int slot) {
        if (slot == -1) {
            return;
        }
        final int prev = mc.player.inventory.currentItem;

        mc.player.connection.sendPacket(new CPacketHeldItemChange(slot));
        placeBlock(pos);
        mc.player.connection.sendPacket(new CPacketHeldItemChange(prev));
    }

    public static int getHotbarSlot(final Block block) {
        for (int i = 0; i < 9; ++i) {
            final Item item = mc.player.inventory.getStackInSlot(i).getItem();
            if (item instanceof ItemBlock && ((ItemBlock) item).getBlock().equals(block)) {
                return i;
            }
        }
        return -1;
    }

    private Block getBlock() {
        if (!Echest.getValue() && getHotbarSlot(Blocks.OBSIDIAN)!=-1 || getHotbarSlot(Blocks.OBSIDIAN)!=-1 && getHotbarSlot(Blocks.ENDER_CHEST)==-1) {
            return Blocks.OBSIDIAN;
        }else if(getHotbarSlot(Blocks.ENDER_CHEST)!=-1){
            return Blocks.ENDER_CHEST;
        }

        return null;
    }


}

