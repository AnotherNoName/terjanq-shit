package be.p7n.client.features.modules.movement;

import be.p7n.client.features.modules.Module;
import be.p7n.client.features.setting.Setting;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;

public class ReverseStep
        extends Module {
    private static ReverseStep INSTANCE = new ReverseStep();
    private final Setting<Boolean> twoBlocks = this.register(new Setting<Boolean>("2Blocks", Boolean.FALSE));

    public ReverseStep() {
        super("ReverseStep", "ReverseStep.", Module.Category.MOVEMENT, true, false, false);
        this.setInstance();
    }

    public static ReverseStep getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new ReverseStep();
        }
        return INSTANCE;
    }

    private void setInstance() {
        INSTANCE = this;
    }

    @Override
    public
    void onUpdate ( ) {
        if ( fullNullCheck ( ) ) {
            return;
        }
        if ( mc.player != null && mc.world != null && mc.player.onGround && ! mc.player.isSneaking ( ) && ! mc.player.isInWater ( ) && ! mc.player.isDead && ! mc.player.isInLava ( ) && ! mc.player.isOnLadder ( ) && ! mc.player.noClip && ! mc.gameSettings.keyBindSneak.isKeyDown ( ) && ! mc.gameSettings.keyBindJump.isKeyDown ( ) ) {
            if ( ReverseStep.mc.player.onGround ) {
                ReverseStep.mc.player.motionY -= 1.0;
            }
        }
    }
}

