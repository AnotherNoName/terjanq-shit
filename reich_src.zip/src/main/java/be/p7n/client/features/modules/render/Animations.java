package be.p7n.client.features.modules.render;

import be.p7n.client.features.setting.Setting;
import be.p7n.client.features.modules.Module;

public class Animations
        extends Module {
    public Setting<AnimMode> animMode = register(new Setting("Mode", AnimMode.Normal));
    public Animations() {
        super("Animations", "1.8 hit animations", Module.Category.RENDER, true, false, false);
    }


    @Override
    public void onUpdate() {
        if (this.animMode.getValue() == AnimMode.Retarded) {
            if (Animations.mc.entityRenderer.itemRenderer.prevEquippedProgressMainHand >= 0.9) {
                Animations.mc.entityRenderer.itemRenderer.equippedProgressMainHand = 1.0f;
                Animations.mc.entityRenderer.itemRenderer.itemStackMainHand = Animations.mc.player.getHeldItemMainhand();
            }
        } else {
            Animations.mc.entityRenderer.itemRenderer.equippedProgressMainHand = 1.0f;
            Animations.mc.entityRenderer.itemRenderer.itemStackMainHand = Animations.mc.player.getHeldItemMainhand();
        }
    }

    public enum AnimMode {
        Retarded, Normal
    }
}

