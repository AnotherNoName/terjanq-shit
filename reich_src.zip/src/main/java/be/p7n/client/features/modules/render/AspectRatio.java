package be.p7n.client.features.modules.render;

import be.p7n.client.features.modules.Module;
import be.p7n.client.features.setting.Setting;
import be.p7n.client.util.Util;
import be.p7n.client.event.events.PerspectiveEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class AspectRatio
        extends Module {
    public Setting<Double> aspect = this.register(new Setting<Double>("Stretch", Util.mc.displayWidth / Util.mc.displayHeight +0.0, 0.0, 3.0));


    public AspectRatio() {
        super("AspectRatio", "Stretched res like fortnite (p100)", Category.RENDER, true, false, false);

    }

    @SubscribeEvent
    public void onPerspectiveEvent(PerspectiveEvent event){
        event.setAspect(aspect.getValue().floatValue());
    }
}