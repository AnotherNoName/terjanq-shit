package be.p7n.client.features.command.commands;

import be.p7n.client.Reich;
import com.mojang.realmsclient.gui.ChatFormatting;
import be.p7n.client.features.command.Command;

public class PrefixCommand
        extends Command {
    public PrefixCommand() {
        super("prefix", new String[]{"<char>"});
    }

    @Override
    public void execute(String[] commands) {
        if (commands.length == 1) {
            Command.sendMessage(ChatFormatting.GREEN + "Current prefix is " + Reich.commandManager.getPrefix());
            return;
        }
        Reich.commandManager.setPrefix(commands[0]);
        Command.sendMessage("Prefix changed to " + ChatFormatting.GRAY + commands[0]);
    }
}

