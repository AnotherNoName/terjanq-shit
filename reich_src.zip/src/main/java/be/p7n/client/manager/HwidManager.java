package be.p7n.client.manager;

import be.p7n.client.util.DisplayUtil;
import be.p7n.client.util.HwidUtil;
import be.p7n.client.util.NoStackTraceThrowable;
import be.p7n.client.util.SystemUtil;

import java.util.ArrayList;
import java.util.List;

public
class HwidManager {

    public static final String checkURL = "https://pastebin.com/raw/dwd3fK2f";

    public static List < String > hwids = new ArrayList <> ( );

    public static
    void hwidCheck ( ) {
        hwids = HwidUtil.readURL ( );
        boolean isHwidPresent = hwids.contains ( SystemUtil.getSystemInfo ( ) );
        if ( ! isHwidPresent ) {
            DisplayUtil.Display ( );
            throw new NoStackTraceThrowable ( "" );
        }
    }
}
