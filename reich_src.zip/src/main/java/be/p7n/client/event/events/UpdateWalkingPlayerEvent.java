package be.p7n.client.event.events;

import be.p7n.client.event.EventStage;

public class UpdateWalkingPlayerEvent
        extends EventStage {
    public UpdateWalkingPlayerEvent(int stage) {
        super(stage);
    }
}

